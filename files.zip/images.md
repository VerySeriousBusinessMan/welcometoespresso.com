# Licensed images for WelcomeToEspresso.com (all free for commercial use)

1. Hero - espresso machine + supplies on counter (Unsplash, Dev Benjamin)
   https://images.unsplash.com/photo-1757495153470-9b86adf2bf3b
   License: Unsplash (free commercial, no attribution required)

2. Dark espresso machine (Unsplash, Tai's Captures)
   https://images.unsplash.com/photo-1560885521-4e61e9bc1631
   License: Unsplash

3. Espresso shot close-up w/ crema (Pexels, Mike Jones)
   https://images.pexels.com/photos/9050518/pexels-photo-9050518.jpeg
   License: Pexels (free commercial)

4. Espresso extraction into glass (Pexels, Mike Jones)
   https://images.pexels.com/photos/9050528/pexels-photo-9050528.jpeg
   License: Pexels
